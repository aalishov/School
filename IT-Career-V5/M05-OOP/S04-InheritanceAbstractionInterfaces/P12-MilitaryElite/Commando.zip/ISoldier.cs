﻿namespace MilitaryElite
{
    public interface ISoldier
    {
        string FirstName { get; }
        int Id { get; }
        string LastName { get; }
    }
}