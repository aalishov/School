﻿namespace MilitaryElite
{
    public interface ICommando
    {
        string ToString();
    }
}