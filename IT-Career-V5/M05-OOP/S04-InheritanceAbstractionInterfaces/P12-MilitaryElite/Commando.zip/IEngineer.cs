﻿namespace MilitaryElite
{
    public interface IEngineer
    {
        string ToString();
    }
}