﻿namespace Shapes
{
    public interface IDrawable
    {
        public void Draw();
    }
}
