﻿using System;
using System.Collections.Generic;
using System.Text;

public class Motorcycle : Vehicle
{
    public Motorcycle(double fuel, int horsePower) : base(fuel, horsePower)
    {
    }
}

