﻿using System;
using System.Collections.Generic;
using System.Text;

public class FamilyCar : Car
{
    public FamilyCar(double fuel, int horsePower) : base(fuel, horsePower)
    {
    }
}

