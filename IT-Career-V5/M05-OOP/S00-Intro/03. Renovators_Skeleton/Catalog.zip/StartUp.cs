﻿using System;

namespace Renovators
{
    //C# Advanced Exam - 25 June 2022
    public class StartUp
    {
        static void Main()
        {
            Catalog catalog = new Catalog("Demo", 5, "DemoProject");
        }
    }
}
