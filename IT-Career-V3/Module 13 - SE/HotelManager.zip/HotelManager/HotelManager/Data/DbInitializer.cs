﻿namespace HotelManager.Data
{
    using HotelManager.Data.Models;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using System;
    using System.Linq;
    public class DbInitializer
    {
        public static void Initialize(AppDbContext context, IServiceProvider services)
        {
            // Get a logger
            var logger = services.GetRequiredService<ILogger<DbInitializer>>();
            var userManager = services.GetRequiredService<UserManager<User>>();
            var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();

            // Make sure the database is created
            // We already did this in the previous step
            context.Database.EnsureCreated();

            if (context.Roles.Any())
            {
                logger.LogInformation("The database already has roles");
            }
            else
            {
                roleManager.CreateAsync(new IdentityRole() { Name = "Admin" }).Wait();
                roleManager.CreateAsync(new IdentityRole() { Name = "User" }).Wait();
            }

            if (context.Users.Any())
            {
                logger.LogInformation("The database already has users");
            }
            else
            {
                User user = new User()
                {
                    UserName = "admin",
                    Email = "admin@admin.bg"
                };
                userManager.CreateAsync(user, "admin").Wait();
                userManager.AddToRoleAsync(user, "admin");
            }
        }
    }
}
